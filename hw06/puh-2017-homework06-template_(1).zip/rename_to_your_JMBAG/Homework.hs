module Homework where
--
import Data.List
import Data.Time.Clock ( UTCTime(..) )
import Data.Time.Calendar ( Day, gregorianMonthLength, fromGregorian )
import Data.Time.Format ( formatTime, defaultTimeLocale )
--

-- Task 01
data Pred

eval :: Pred -> Bool
eval = undefined

-- Task 02

dateFromDescription :: String -> Day
dateFromDescription = undefined

-- Task 03

data Tree a
  = Leaf | Node a (Tree a) (Tree a)
  deriving (Eq, Show)

-- a)
treeFilter :: (a -> Bool) -> Tree a -> Tree a
treeFilter = undefined

-- b)
levelMap :: (Int -> a -> b) -> Tree a -> Tree b
levelMap = undefined

-- c)
isSubtree :: Eq a => Tree a -> Tree a -> Bool
isSubtree = undefined

-- Task 04
data Category

parseCategories :: [String] -> [Category]
parseCategories = undefined

printCategories :: [Category] -> [String]
printCategories = undefined